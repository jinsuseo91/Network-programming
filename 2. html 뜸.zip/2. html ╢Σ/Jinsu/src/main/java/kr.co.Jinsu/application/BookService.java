package kr.co.Jinsu.application;

import kr.co.Jinsu.domain.Book;
import kr.co.Jinsu.infrastructure.DatabaseBookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    @Autowired
    private DatabaseBookRepository bookRepository;

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public Book getBookById(Long id) {
        return bookRepository.findById(id);
    }

    public void addBook(Book book) {
        bookRepository.add(book);
    }

    public void borrowBook(Long id) {
        Book book = bookRepository.findById(id);
        if (book.getNumberofbook() > 0 && !book.isBorrowed()) {
            book.setNumberofbook(book.getNumberofbook() - 1);
            book.setBorrowed(true);
            bookRepository.update(book);
        }
    }

    public void returnBook(Long id) {
        Book book = bookRepository.findById(id);
        book.setNumberofbook(book.getNumberofbook() + 1);
        book.setBorrowed(false);
        bookRepository.update(book);
    }

    public List<Book> findBooksByTitle(String title) {
        return bookRepository.findByTitleContaining(title);
    }

    public List<Book> findBooksByAuthor(String author) {
        return bookRepository.findByAuthorContaining(author);
    }

    public List<Book> findBooksByPublisher(String publisher) {
        return bookRepository.findByPublisherContaining(publisher);
    }

    public List<Book> findBooksByPublishingYear(int year) {
        return bookRepository.findByPublishingYearGreaterThan(year);
    }
}