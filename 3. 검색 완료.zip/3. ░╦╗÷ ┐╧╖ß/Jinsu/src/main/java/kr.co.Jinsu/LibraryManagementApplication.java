package kr.co.Jinsu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibraryManagementApplication.class, args);
    }
}
//{
//        "title": "아드",
//        "author": "손원평",
//        "publisher": "창비",
//        "publishingyear": 2017,
//        "price": 12000,
//        "borrowed": false,
//        "numberOfBooks": 3,
//        "category": "소설"
//}