package kr.co.Jinsu.infrastructure;

import kr.co.Jinsu.domain.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class DatabaseBookRepository {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    @Autowired
    public DatabaseBookRepository(NamedParameterJdbcTemplate namedParameterJdbcTemplate) {
        this.namedParameterJdbcTemplate = namedParameterJdbcTemplate;
    }

    public Book add(Book book) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        SqlParameterSource namedParameter = new BeanPropertySqlParameterSource(book);

        namedParameterJdbcTemplate.update(
                "INSERT INTO BookData07 (title, author, publisher, publishingyear, price, borrowed, numberofbook, category) VALUES (:title, :author, :publisher, :publishingYear, :price, :borrowed, :numberofbook, :category)",
                namedParameter,
                keyHolder
        );

        Long generatedId = keyHolder.getKey().longValue();
        book.setId(generatedId);

        return book;
    }

    public Book findById(Long id) {
        SqlParameterSource namedParameter = new MapSqlParameterSource("id", id);

        Book book = namedParameterJdbcTemplate.queryForObject(
                "SELECT id, title, author, publisher, publishingyear, price, borrowed, numberofbook, category FROM BookData07 WHERE id=:id",
                namedParameter,
                new BeanPropertyRowMapper<>(Book.class)
        );

        return book;
    }

    public List<Book> findAll() {
        List<Book> books = namedParameterJdbcTemplate.query(
                "SELECT * FROM BookData07",
                new BeanPropertyRowMapper<>(Book.class)
        );

        return books;
    }

    public List<Book> findByTitleContaining(String title) {
        SqlParameterSource namedParameter = new MapSqlParameterSource("title", "%" + title + "%");

        List<Book> books = namedParameterJdbcTemplate.query(
                "SELECT * FROM BookData07 WHERE title LIKE :title",
                namedParameter,
                new BeanPropertyRowMapper<>(Book.class)
        );

        return books;
    }

    public List<Book> findByAuthorContaining(String author) {
        SqlParameterSource namedParameter = new MapSqlParameterSource("author", "%" + author + "%");

        List<Book> books = namedParameterJdbcTemplate.query(
                "SELECT * FROM BookData07 WHERE author LIKE :author",
                namedParameter,
                new BeanPropertyRowMapper<>(Book.class)
        );

        return books;
    }

    public List<Book> findByPublisherContaining(String publisher) {
        SqlParameterSource namedParameter = new MapSqlParameterSource("publisher", "%" + publisher + "%");

        List<Book> books = namedParameterJdbcTemplate.query(
                "SELECT * FROM BookData07 WHERE publisher LIKE :publisher",
                namedParameter,
                new BeanPropertyRowMapper<>(Book.class)
        );

        return books;
    }

    public List<Book> findByPublishingYearGreaterThan(int year) {
        SqlParameterSource namedParameter = new MapSqlParameterSource("year", year);

        List<Book> books = namedParameterJdbcTemplate.query(
                "SELECT * FROM BookData07 WHERE publishingyear > :year",
                namedParameter,
                new BeanPropertyRowMapper<>(Book.class)
        );

        return books;
    }

    public List<Book> findByCategoryContaining(String category) {
        SqlParameterSource namedParameter = new MapSqlParameterSource("category", "%" + category + "%");

        List<Book> books = namedParameterJdbcTemplate.query(
                "SELECT * FROM BookData07 WHERE category LIKE :category",
                namedParameter,
                new BeanPropertyRowMapper<>(Book.class)
        );

        return books;
    }


    public Book update(Book book) {
        SqlParameterSource namedParameter = new BeanPropertySqlParameterSource(book);

        namedParameterJdbcTemplate.update(
                "UPDATE BookData07 SET title=:title, author=:author, publisher=:publisher, publishingyear=:publishingYear, price=:price, borrowed=:borrowed, numberofbook=:numberofbook, category=:category WHERE id=:id",
                namedParameter
        );

        return book;
    }

    public void delete(Long id) {
        SqlParameterSource namedParameter = new MapSqlParameterSource("id", id);

        namedParameterJdbcTemplate.update(
                "DELETE FROM BookData07 WHERE id=:id",
                namedParameter
        );
    }
}
