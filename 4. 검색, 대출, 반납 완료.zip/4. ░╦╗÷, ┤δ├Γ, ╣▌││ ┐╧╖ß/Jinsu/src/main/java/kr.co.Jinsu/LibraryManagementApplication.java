package kr.co.Jinsu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(LibraryManagementApplication.class, args);
    }
}
//    {
//        "id": 1,
//        "title": "삼국지",
//        "author": "나관중",
//        "publisher": "민음사",
//        "publishingYear": 1996,
//        "price": 20000.0,
//        "borrowed": false,
//        "numberofbook": 10,
//        "category": "역사소설"
//        },
//        {
//        "id": 2,
//        "title": "어린 왕자",
//        "author": "앙투안 드생텍쥐페리",
//        "publisher": "열린책들",
//        "publishingYear": 2000,
//        "price": 8000.0,
//        "borrowed": false,
//        "numberofbook": 10,
//        "category": "동화"
//        },
//        {
//        "id": 3,
//        "title": "데미안",
//        "author": "헤르만 헤세",
//        "publisher": "민음사",
//        "publishingYear": 2000,
//        "price": 9000.0,
//        "borrowed": false,
//        "numberofbook": 10,
//        "category": "소설"
//        },
//        {
//        "id": 4,
//        "title": "난장이가 쏘아올린 작은 공",
//        "author": "조세희",
//        "publisher": "이성과힘",
//        "publishingYear": 1978,
//        "price": 7000.0,
//        "borrowed": false,
//        "numberofbook": 10,
//        "category": "소설"
//        },
//        {
//        "id": 5,
//        "title": "종의 기원",
//        "author": "정유정",
//        "publisher": "은행나무",
//        "publishingYear": 2016,
//        "price": 15000.0,
//        "borrowed": false,
//        "numberofbook": 10,
//        "category": "소설"
//        },
//        {
//        "id": 6,
//        "title": "미움받을 용기",
//        "author": "기시미 이치로, 고가 후미타케",
//        "publisher": "인플루엔셜",
//        "publishingYear": 2014,
//        "price": 13000.0,
//        "borrowed": false,
//        "numberofbook": 10,
//        "category": "자기계발"
//        },
//        {
//        "id": 7,
//        "title": "아몬드",
//        "author": "손원평",
//        "publisher": "창비",
//        "publishingYear": 2017,
//        "price": 12000.0,
//        "borrowed": false,
//        "numberofbook": 10,
//        "category": "소설"
//        }