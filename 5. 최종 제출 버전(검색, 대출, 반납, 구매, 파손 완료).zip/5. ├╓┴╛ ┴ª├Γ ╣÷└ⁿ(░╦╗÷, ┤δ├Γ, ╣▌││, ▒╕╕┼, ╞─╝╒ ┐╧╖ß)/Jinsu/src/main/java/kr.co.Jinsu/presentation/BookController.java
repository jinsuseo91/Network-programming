package kr.co.Jinsu.presentation;

import kr.co.Jinsu.domain.Book;
import kr.co.Jinsu.application.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService bookService;

    @RequestMapping(method = RequestMethod.GET)
    @ResponseBody
    public List<Book> getAllBooks() {
        return bookService.getAllBooks();
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public Book getBookById(@PathVariable Long id) {
        return bookService.getBookById(id);
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public void addBook(@RequestBody Book book) {
        bookService.addBook(book);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public void updateBookcondition(@PathVariable Long id, @RequestBody Book book) {
        bookService.updateBookcondition(id, book.getBookcondition());
    }

    @RequestMapping(value = "/borrow/{id}", method = RequestMethod.POST)
    @ResponseBody
    public void borrowBook(@PathVariable Long id) {
        bookService.borrowBook(id);
    }

    @RequestMapping(value = "/return/{id}", method = RequestMethod.POST)
    @ResponseBody
    public void returnBook(@PathVariable Long id) {
        bookService.returnBook(id);
    }

    @RequestMapping(value = "/search/title", method = RequestMethod.GET)
    @ResponseBody
    public List<Book> findBooksByTitle(@RequestParam String title) {
        return bookService.findBooksByTitle(title);
    }

    @RequestMapping(value = "/search/author", method = RequestMethod.GET)
    @ResponseBody
    public List<Book> findBooksByAuthor(@RequestParam String author) {
        return bookService.findBooksByAuthor(author);
    }

    @RequestMapping(value = "/search/publisher", method = RequestMethod.GET)
    @ResponseBody
    public List<Book> findBooksByPublisher(@RequestParam String publisher) {
        return bookService.findBooksByPublisher(publisher);
    }

    @RequestMapping(value = "/search/year", method = RequestMethod.GET)
    @ResponseBody
    public List<Book> findBooksByPublishingYear(@RequestParam int year) {
        return bookService.findBooksByPublishingYear(year);
    }

    @RequestMapping(value = "/search/category", method = RequestMethod.GET)
    @ResponseBody
    public List<Book> findBooksByCategory(@RequestParam String category) {
        return bookService.findBooksByCategory(category);
    }

    @RequestMapping(value = "/all_books", method = RequestMethod.GET)
    public String allBooksPage() {
        return "all_books";
    }

    @RequestMapping(value = "/search_book", method = RequestMethod.GET)
    public String searchBookPage() {
        return "search_book";
    }
}
