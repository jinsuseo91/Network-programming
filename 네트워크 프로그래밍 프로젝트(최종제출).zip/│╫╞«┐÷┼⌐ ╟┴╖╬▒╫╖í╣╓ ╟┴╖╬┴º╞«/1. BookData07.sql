-- MySQL dump 10.13  Distrib 8.0.37, for Win64 (x86_64)
--
-- Host: localhost    Database: BookData07
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookdata07`
--

DROP TABLE IF EXISTS `bookdata07`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookdata07` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `publisher` varchar(255) DEFAULT 'A 출판사',
  `publishingyear` int DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `borrowed` tinyint(1) DEFAULT '0',
  `originalbooks` int DEFAULT '0',
  `numberofbook` int DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `bookcondition` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `bookdata07_chk_1` CHECK ((`publishingyear` > 0)),
  CONSTRAINT `bookdata07_chk_2` CHECK ((`price` >= 0)),
  CONSTRAINT `bookdata07_chk_3` CHECK ((`numberofbook` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookdata07`
--

LOCK TABLES `bookdata07` WRITE;
/*!40000 ALTER TABLE `bookdata07` DISABLE KEYS */;
INSERT INTO `bookdata07` VALUES (1,'삼국지','나관중','민음사',1996,20000.00,0,10,10,'역사소설','O'),(2,'어린 왕자','앙투안 드생텍쥐페리','열린책들',2000,8000.00,0,10,10,'동화','O'),(3,'데미안','헤르만 헤세','민음사',2000,9000.00,0,10,10,'소설','O'),(4,'난장이가 쏘아올린 작은 공','조세희','이성과힘',1978,7000.00,0,10,10,'소설','O'),(5,'종의 기원','정유정','은행나무',2016,15000.00,0,10,10,'소설','O'),(6,'미움받을 용기','기시미 이치로, 고가 후미타케','인플루엔셜',2014,13000.00,0,10,10,'자기계발','O'),(7,'아몬드','손원평','창비',2017,12000.00,1,10,9,'소설','X'),(8,'1','2','3',4,5.00,0,6,6,'7','X');
/*!40000 ALTER TABLE `bookdata07` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-13 19:09:54
